//
//  KaiserMesssageModule.h
//  KaiserMesssageModule
//
//  Created by Chintan Prajapati on 13/07/17.
//  Copyright © 2017 Infostretch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KaiserMesssageModule.
FOUNDATION_EXPORT double KaiserMesssageModuleVersionNumber;

//! Project version string for KaiserMesssageModule.
FOUNDATION_EXPORT const unsigned char KaiserMesssageModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KaiserMesssageModule/PublicHeader.h>


