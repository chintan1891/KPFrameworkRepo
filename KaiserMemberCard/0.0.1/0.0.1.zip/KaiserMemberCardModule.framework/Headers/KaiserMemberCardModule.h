//
//  KaiserMemberCardModule.h
//  KaiserMemberCardModule
//
//  Created by Chintan Prajapati on 13/07/17.
//  Copyright © 2017 Infostretch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KaiserMemberCardModule.
FOUNDATION_EXPORT double KaiserMemberCardModuleVersionNumber;

//! Project version string for KaiserMemberCardModule.
FOUNDATION_EXPORT const unsigned char KaiserMemberCardModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KaiserMemberCardModule/PublicHeader.h>


