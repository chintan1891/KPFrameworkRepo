//
//  KaiserDrawerMenuModule.h
//  KaiserDrawerMenuModule
//
//  Created by Chintan Prajapati on 12/07/17.
//  Copyright © 2017 Infostretch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KaiserDrawerMenuModule.
FOUNDATION_EXPORT double KaiserDrawerMenuModuleVersionNumber;

//! Project version string for KaiserDrawerMenuModule.
FOUNDATION_EXPORT const unsigned char KaiserDrawerMenuModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KaiserDrawerMenuModule/PublicHeader.h>


