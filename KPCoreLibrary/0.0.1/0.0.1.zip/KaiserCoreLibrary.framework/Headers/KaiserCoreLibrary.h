//
//  KaiserCoreLibrary.h
//  KaiserCoreLibrary
//
//  Created by Chintan Prajapati on 07/07/17.
//  Copyright © 2017 Infostretch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KaiserCoreLibrary.
FOUNDATION_EXPORT double KaiserCoreLibraryVersionNumber;

//! Project version string for KaiserCoreLibrary.
FOUNDATION_EXPORT const unsigned char KaiserCoreLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KaiserCoreLibrary/PublicHeader.h>


