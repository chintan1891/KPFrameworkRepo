//
//  KaiserHomeScreenModule.h
//  KaiserHomeScreenModule
//
//  Created by Chintan Prajapati on 11/07/17.
//  Copyright © 2017 Infostretch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KaiserHomeScreenModule.
FOUNDATION_EXPORT double KaiserHomeScreenModuleVersionNumber;

//! Project version string for KaiserHomeScreenModule.
FOUNDATION_EXPORT const unsigned char KaiserHomeScreenModuleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KaiserHomeScreenModule/PublicHeader.h>


